// runtime il2cpp dumper: finds the REAL, already-decrypted libil2cpp.so + global-metadata.dat inside a running
// process's memory and writes them out -- not whatever 4MB loader-stub sits on disk pre-launch.
//
// why this works even with encrypted-on-disk metadata/libs: il2cpp cannot execute a global-metadata blob or
// call into libil2cpp while either is still encrypted. Whatever custom loader the game uses MUST decrypt them
// into memory before jumping in, so by the time Unity has actually loaded (first frame rendered), both are
// sitting in RAM in plain, correct, directly-usable form. We don't reverse the encryption -- we just wait for
// the app to do it for us, then copy the result.
//
// usage: dump_core -p <pkg substring> -o <out dir>
// out:   <out>/libil2cpp.so      (re-paginated from its ELF program headers, not raw mapping bytes)
// out:   <out>/global-metadata.dat
// out:   <out>/report.txt
#include "mem.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <chrono>
#include <thread>
#include <vector>
#include <string>
#include <fstream>

static double now_s() {
    using namespace std::chrono;
    return duration<double>(steady_clock::now().time_since_epoch()).count();
}

// ---- ELF64 structures (just enough to read program headers and re-stitch the on-disk image) ----
struct Elf64_Ehdr {
    unsigned char e_ident[16];
    uint16_t e_type, e_machine;
    uint32_t e_version;
    uint64_t e_entry, e_phoff, e_shoff;
    uint32_t e_flags;
    uint16_t e_ehsize, e_phentsize, e_phnum, e_shentsize, e_shnum, e_shstrndx;
};
struct Elf64_Phdr {
    uint32_t p_type, p_flags;
    uint64_t p_offset, p_vaddr, p_paddr, p_filesz, p_memsz, p_align;
};
static const uint32_t PT_LOAD = 1;

struct Report {
    std::vector<std::string> lines;
    void add(const std::string& s) { lines.push_back(s); fprintf(stderr, "%s\n", s.c_str()); }
};

// Dumps libil2cpp.so by walking its ELF program headers live in the target process and writing each PT_LOAD
// segment to its FILE offset (not its runtime vaddr) -- producing a normal, loadable .so, not a memory snapshot.
static bool dump_elf(IMem& m, uint64_t base, const std::string& outPath, Report& rep, size_t& outSize) {
    Elf64_Ehdr eh{};
    if (!m.read(base, &eh, sizeof eh)) { rep.add("ELF: can't read header at base"); return false; }
    if (memcmp(eh.e_ident, "\x7f""ELF", 4) != 0) { rep.add("ELF: bad magic -- base is not an ELF image"); return false; }
    if (eh.e_ident[4] != 2) { rep.add("ELF: not 64-bit (unexpected on arm64 target)"); return false; }
    if (eh.e_phnum == 0 || eh.e_phnum > 200) { rep.add("ELF: implausible phnum " + std::to_string(eh.e_phnum)); return false; }

    std::vector<Elf64_Phdr> ph(eh.e_phnum);
    if (!m.read(base + eh.e_phoff, ph.data(), ph.size() * sizeof(Elf64_Phdr))) { rep.add("ELF: can't read program headers"); return false; }

    uint64_t maxEnd = 0;
    for (auto& p : ph) if (p.p_type == PT_LOAD) maxEnd = std::max(maxEnd, p.p_offset + p.p_filesz);
    if (maxEnd == 0 || maxEnd > 300ull * 1024 * 1024) { rep.add("ELF: implausible image size"); return false; }

    std::vector<uint8_t> img(maxEnd, 0);
    memcpy(img.data(), &eh, sizeof eh);
    for (size_t i = 0; i < ph.size(); i++) memcpy(img.data() + eh.e_phoff + i * sizeof(Elf64_Phdr), &ph[i], sizeof(Elf64_Phdr));

    size_t loaded = 0;
    for (auto& p : ph) {
        if (p.p_type != PT_LOAD || p.p_filesz == 0) continue;
        uint64_t segBase = base + p.p_vaddr;
        size_t left = p.p_filesz, off = 0;
        bool ok = true;
        while (left > 0) {
            size_t chunk = left < (1u << 16) ? left : (1u << 16);
            if (!m.read(segBase + off, img.data() + p.p_offset + off, chunk)) { ok = false; break; }
            off += chunk; left -= chunk;
        }
        if (ok) loaded++;
        else rep.add("ELF: segment read failed at vaddr 0x" + std::to_string(p.p_vaddr) + " (paged out / partially unmapped)");
    }
    if (loaded == 0) { rep.add("ELF: zero PT_LOAD segments read successfully"); return false; }

    std::ofstream f(outPath, std::ios::binary);
    if (!f) { rep.add("ELF: can't open " + outPath + " for write"); return false; }
    f.write((const char*)img.data(), img.size());
    outSize = img.size();
    return true;
}

// global-metadata.dat: magic 0xFAB11BAF little-endian at offset 0, version int32 at offset 4.
// We scan RW (not necessarily file-backed -- a custom loader may decrypt into an anonymous mmap) regions for
// the magic, then sanity-check the version and a plausible string-literal-table offset before accepting a hit,
// because the 4-byte magic alone can collide with game data.
static bool looks_like_metadata(IMem& m, uint64_t addr, int& version) {
    uint8_t hdr[64];
    if (!m.read(addr, hdr, sizeof hdr)) return false;
    uint32_t magic; memcpy(&magic, hdr, 4);
    if (magic != 0xFAB11BAFu) return false;
    int32_t ver; memcpy(&ver, hdr + 4, 4);
    if (ver < 16 || ver > 40) return false; // known il2cpp metadata version range
    version = ver;
    return true;
}

static bool find_and_dump_metadata(IMem& m, const std::string& outPath, Report& rep, size_t& outSize) {
    auto regs = m.regions();
    int bestVersion = 0;
    uint64_t bestAddr = 0, bestLen = 0;
    for (auto& r : regs) {
        if (!r.r) continue;
        uint64_t len = r.end - r.start;
        if (len < 0x1000 || len > 256ull * 1024 * 1024) continue;
        int ver = 0;
        if (!looks_like_metadata(m, r.start, ver)) continue;
        // bigger plausible region wins (a real metadata blob is usually several MB; a false positive region is tiny)
        if (len > bestLen) { bestLen = len; bestAddr = r.start; bestVersion = ver; }
    }
    if (!bestAddr) { rep.add("metadata: no 0xFAB11BAF signature found in any readable region yet"); return false; }
    rep.add("metadata: candidate at 0x" + std::to_string(bestAddr) + " version=" + std::to_string(bestVersion) + " region_len=" + std::to_string(bestLen));

    // metadata.dat's real size is NOT the whole mapping (the mapping is often rounded up / shared with other data).
    // header layout (v24+): after magic+version, a sequence of (offset,size) int32 pairs for each table; the
    // file's true length is (last table's offset + size) rounded up -- but tables are defined per-version and we
    // don't want to hardcode every layout here. Practical approach: copy the whole region (bounded, see above);
    // a few extra trailing MB of zero/adjacent-data bytes do not stop Il2CppDumper from parsing a valid file.
    std::vector<uint8_t> buf(bestLen);
    size_t done = 0;
    while (done < bestLen) {
        size_t chunk = (bestLen - done) < (1u << 16) ? (bestLen - done) : (1u << 16);
        if (!m.read(bestAddr + done, buf.data() + done, chunk)) break;
        done += chunk;
    }
    if (done < 4096) { rep.add("metadata: read came back too short (" + std::to_string(done) + " bytes)"); return false; }
    buf.resize(done);
    std::ofstream f(outPath, std::ios::binary);
    if (!f) { rep.add("metadata: can't open " + outPath + " for write"); return false; }
    f.write((const char*)buf.data(), buf.size());
    outSize = buf.size();
    return true;
}

int main(int argc, char** argv) {
    std::string pkg, outDir = ".";
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "-p") && i + 1 < argc) pkg = argv[++i];
        else if (!strcmp(argv[i], "-o") && i + 1 < argc) outDir = argv[++i];
    }
    if (pkg.empty()) { fprintf(stderr, "usage: dump_core -p <pkg substring> -o <out dir>\n"); return 1; }
    if (getuid() != 0) { fprintf(stderr, "needs root\n"); return 1; }

    Report rep;
    rep.add("looking for process matching '" + pkg + "' ...");
    int pid = 0;
    double t0 = now_s();
    while (now_s() - t0 < 60.0) {
        pid = Proc::find_pid(pkg);
        if (pid) break;
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
    }
    if (!pid) { rep.add("timed out waiting for the game process -- start the game first, then run this"); goto done; }
    rep.add("pid=" + std::to_string(pid));

    {
        Proc proc;
        if (!proc.attach(pid)) { rep.add("attach() failed"); goto done; }

        // wait for libil2cpp.so to actually be mapped AND for its headers to look like a real ELF -- a loader
        // stub may map a placeholder first and replace it, or map nothing until the splash screen finishes.
        uint64_t base = 0;
        t0 = now_s();
        while (now_s() - t0 < 90.0) {
            base = proc.module_base("libil2cpp.so");
            if (base) {
                uint8_t m4[4];
                if (proc.read(base, m4, 4) && memcmp(m4, "\x7f""ELF", 4) == 0) break;
            }
            base = 0;
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
        }
        if (!base) { rep.add("libil2cpp.so never appeared as a valid ELF image in 90s"); goto done; }
        rep.add("libil2cpp.so base=0x" + std::to_string(base));

        // give the runtime a few more seconds after the module appears -- global-metadata decryption can happen
        // slightly after the .so is mapped, during Il2CppRuntimeInitialize
        std::this_thread::sleep_for(std::chrono::seconds(3));

        size_t soSize = 0, metaSize = 0;
        bool soOk = dump_elf(proc, base, outDir + "/libil2cpp.so", rep, soSize);
        bool metaOk = find_and_dump_metadata(proc, outDir + "/global-metadata.dat", rep, metaSize);

        if (soOk) rep.add("libil2cpp.so written: " + std::to_string(soSize) + " bytes");
        if (metaOk) rep.add("global-metadata.dat written: " + std::to_string(metaSize) + " bytes");
        rep.add(soOk && metaOk ? "RESULT: ok, both files look real -- run Il2CppDumper on them" : "RESULT: incomplete, see lines above");
    }

done:
    std::ofstream f(outDir + "/report.txt");
    for (auto& l : rep.lines) f << l << "\n";
    return 0;
}
