package rd.exe;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

/** One button: copies dump_core (arm64) from assets, runs it as root against the matching running process,
 *  and shows the live log. Output lands in /sdcard/rtdump/<pkg>/ -- libil2cpp.so + global-metadata.dat +
 *  report.txt, ready to send back as-is. */
public class MainActivity extends Activity {
    private static final int BG = 0xFF0E1013, CARD = 0xFF171A1F, EDGE = 0xFF262B32, ACCENT = 0xFF4ADE80, TEXT = 0xFFE8EAED, DIM = 0xFF8B929B;
    private TextView log;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable rounded(int fill, int stroke, float r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(r));
        if (stroke != 0) g.setStroke(dp(1), stroke);
        return g;
    }

    private TextView label(String t, float sp, int col, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(col);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(20), dp(44), dp(20), dp(20));

        root.addView(label("RTDumper", 30, TEXT, true));
        root.addView(label("Dumps the real, decrypted libil2cpp.so + global-metadata.dat out of a running game's memory. Root required. Start the game first, join a match, then press Dump.", 13, DIM, false));

        final EditText pkgIn = new EditText(this);
        pkgIn.setHint("package name substring, e.g. oxide");
        pkgIn.setHintTextColor(DIM);
        pkgIn.setTextColor(TEXT);
        pkgIn.setInputType(InputType.TYPE_CLASS_TEXT);
        pkgIn.setBackground(rounded(CARD, EDGE, 10));
        pkgIn.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
        ip.topMargin = dp(16);
        root.addView(pkgIn, ip);

        TextView go = label("DUMP", 16, 0xFF0B0D10, true);
        go.setGravity(Gravity.CENTER);
        go.setBackground(rounded(ACCENT, 0, 12));
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, dp(52));
        gp.topMargin = dp(12);
        go.setLayoutParams(gp);
        root.addView(go);

        log = label("", 12, TEXT, false);
        log.setTypeface(Typeface.MONOSPACE);
        ScrollView sc = new ScrollView(this);
        sc.setBackground(rounded(CARD, EDGE, 10));
        sc.addView(log);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 0, 1f);
        sp.topMargin = dp(16);
        sc.setPadding(dp(10), dp(10), dp(10), dp(10));
        root.addView(sc, sp);

        go.setOnClickListener(v -> {
            String pkg = pkgIn.getText().toString().trim();
            if (pkg.isEmpty()) { append("enter a package name substring first"); return; }
            go.setEnabled(false);
            log.setText("");
            new Thread(() -> runDump(pkg, go)).start();
        });

        setContentView(root);
    }

    private void append(String s) {
        ui.post(() -> log.setText(log.getText() + s + "\n"));
    }

    private void runDump(String pkg, TextView go) {
        try {
            File bin = new File(getFilesDir(), "dump_core");
            try (InputStream in = getAssets().open("dump_core"); FileOutputStream out = new FileOutputStream(bin)) {
                byte[] buf = new byte[65536];
                int k;
                while ((k = in.read(buf)) > 0) out.write(buf, 0, k);
            }
            bin.setReadable(true, false);

            File outDir = new File(Environment.getExternalStorageDirectory(), "rtdump/" + pkg);
            String cmd = "cp '" + bin.getAbsolutePath() + "' /data/local/tmp/dump_core && chmod 755 /data/local/tmp/dump_core && mkdir -p '" + outDir.getAbsolutePath() + "' && chmod 777 '" + outDir.getAbsolutePath() + "' && exec /data/local/tmp/dump_core -p '" + pkg + "' -o '" + outDir.getAbsolutePath() + "'";
            append("running as root, waiting for '" + pkg + "' process + libil2cpp.so (up to ~2.5 min total)...");
            Process proc = new ProcessBuilder("su", "-c", cmd).redirectErrorStream(true).start();
            BufferedReader br = new BufferedReader(new InputStreamReader(proc.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) append(line);
            int rc = proc.waitFor();
            append("exit code " + rc);
            append("output dir: " + outDir.getAbsolutePath());
        } catch (Exception e) {
            append("error: " + e);
        } finally {
            ui.post(() -> go.setEnabled(true));
        }
    }
}
